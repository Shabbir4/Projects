var css = document.querySelector("h3");
var color1 = document.querySelector(".color1");
var color2 = document.querySelector(".color2");
var body = document.getElementById("gradient");
var butt= document.getElementById("random");

function setGradient() {
	body.style.background = 
	"linear-gradient(to right, " 
	+ color1.value 
	+ ", " 
	+ color2.value 
	+ ")";

	css.textContent = body.style.background + ";";
}

color1.addEventListener("input", setGradient);

color2.addEventListener("input", setGradient);

// function makeid() {
 /* var text = "";
  var possible = "abcdef0123456789";

  for (var i = 0; i < 6; i++)
    text += possible.charAt(Math.floor(Math.random() * possible.length));
    console.log(text)

 
}*/
 // var a=(makeid());
 // var b=(makeid());

  function randomNumber(){
	var randomColor = "#000000".replace(/0/g,function(){return (~~(Math.random()*16)).toString(16);})
 var randomColor2= "#000000".replace(/0/g,function(){return (~~(Math.random()*16)).toString(16);})
 console.log(randomColor);
 console.log(randomColor2);
 
	body.style.background=
	"linear-gradient(to right,"
	+ randomColor
	+ ", " 
	+ randomColor2
	+ ")";
}
butt.addEventListener("click", randomNumber);