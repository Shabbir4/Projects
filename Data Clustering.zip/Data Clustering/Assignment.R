names(DatasetForClustering)
dfi <- DatasetForClustering[, -c(1,2,3,25)]
dim(dfi)
gender <-factor(dfi$gndr, levels=c("M","F","Unspecfied"), labels=c(0,1,2))
dfi$gndr <- gender
dfi$cntc_nbr_gvn_ind <- NULL
dfi$emp_ind <- NULL
dfi$yr_of_brth <- NULL
dim(dfi)
di <- dfi[, -c(18,18)]
me <- apply(di, 2, mean)
se <- apply(di,2,sd)
di <- scale(di,me,se)

wss <- (nrow(di)-1)*sum(apply(di, 2, var))
for (i in 2:15) wss[i]<- sum(kmeans(di, centers = i)$withinss)
b <- plot(1:15, wss, type="b",xlab="Number of Clusters", ylab="Within group SS")
seed(245)
kmf <- kmeans(di,3)
kmf
plot(AvgDebitAmount~AccountNumber12, dt, col=kmf$cluster)
library(ppclust)
library(factoextra)
library(cluster)
library(fclust)
library(ggplot2)
res.fcm <- fcm(di, centers=3)
as.data.frame(res.fcm$u)
dim(dfi)
fanny(dfi, 3)
installed.packages()
plot(AvgDebitAmount~AccountNumber12, dfi)